
True Type Font: Ice Pixel-7 version 1.0


EULA
-==-
The font Ice Pixel-7 is freeware for home use only.


DESCRIPTION
-=========-
Original pixel font like ice text string. Cyrillic code pages is supported.

Files in ice_pixel-7.zip:
       	readme.txt     		this file;
        ice_pixel-7.ttf    	regular font;
	ice_pixel-7.fon   	font in windows "FON" format;
	ice_pixel-7_screen.png	preview image.

Please visit http://www.styleseven.com/ for download our other products as freeware as shareware.
We will welcome any useful suggestions and comments; please send them to ms-7@styleseven.com


FREEWARE USE (NOTES)
-=================-
Also you may: 
 * Use the font in freeware software (credit needed);
 * Use the font for your education process.


COMMERCIAL OR BUSINESS USE
-========================-
Please contact us ($24.95).
You may:
 * Include the font to your installation;
 * Use one license up to 100 computers in your office.


AUTHOR
-====-
Sizenko Alexander
Style-7
http://www.styleseven.com
Created: December 13 2012